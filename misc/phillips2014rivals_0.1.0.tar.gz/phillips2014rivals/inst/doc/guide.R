## ---- echo = FALSE, out.width = "75%", fig.align = 'center', fig.cap = "Diagram of the competitive sampling game."----
knitr::include_graphics("../inst/images/gamediagram.png")

