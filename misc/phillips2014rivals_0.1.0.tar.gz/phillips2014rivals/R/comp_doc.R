#' Competition group data
#'
#' Competition condition data at the group level
#'
#'
#' @format A data frame containing 720 rows and 58 columns.
#' \describe{
#'   \item{Experiment}{integer. - The sequential experiment number. There were 12 in total.}
#'   \item{Order}{string. - The order of the stimuli. Either A, B or C.}
#'   \item{SessionID}{integer. - The session (i.e.; group) of the participants. Each group of participants was in one session.}
#'   \item{Round}{integer. - The round (i.e. game number). Ranges from 1 to 5.}
#'   \item{PlayerID.Session}{integer. The player's ID in the current session. Ranges from 1 to 4}
#'   \item{GameID.Round}{integer. The game id in the current round. Either 1 or 2.}
#'   \item{PlayerID.Game}{integer. The player id in the current game. Either 0 or 1.}
#'   \item{Session.Round.Game.Player}{string. A combination of session, round, game, and player information.}
#'   \item{Urn.0.Mu}{numeric. The mean of urn 0}
#'  }
#' @details Each row corresponds to a participant in a game. Therefore, each game has two rows corresponding to each participant.
#' @source Experiment conducted at the Economic Psychology lab from February 2016 to April 2016
#' @examples
#'
#'
#'
#'  # Histogram of trials
#'
#'  hist(Comp.Game.df$Trials)
#'
#'


"Comp.Game.df"
