#' Opens the package guide
#' @importFrom utils vignette
#' @export
#'

phillips2014rivals.guide <- function() {

  vignette("guide", package = "phillips2014rivals")

}
