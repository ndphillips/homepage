#' Competition simulation function
#'
#' Takes a maximum sampling size (Max.N) a simulation number (Sim.N), and a range of gamble parameters.
#' It returns a list with two elements: Solitary Performance and Competition Performance.
#'
#'
#' \describe{
#'   \item{Max.N}{integer. The maximum number of trials in the game}
#'   \item{Sim.n}{intger. How many simulations should be conducted?}
#'   \item{A.x.Interval, A.p.Interval, A.y.Interval, B.x.Interval, B.p.Interval, B.y.Interval}{numeric. Vectors of length 2 indicating the minimum and maximum possible values of gamble parameters.}
#'   \item{Print.N}{logical. Should progress reports be printed? }
#'  }
#' @return A list with two elements: Solitary Performance and Competition Performance.
#' @examples
#'
#'
#'
#'  # Simulation with a maximum of 10 trials
#'
#'  x <- Competitive.Sampling.Simulation.fun(10, 1e3)
#'
#'


Competitive.Sampling.Simulation.fun <- function(Max.N,
                                                Sim.n,
                                                A.x.Interval = c(0, 100),
                                                A.p.Interval = c(0, 1),
                                                A.y.Interval = c(-100, 0),
                                                B.x.Interval = c(0, 100),
                                                B.p.Interval = c(0, 1),
                                                B.y.Interval = c(-100, 0),
                                                Print.N = TRUE
)

{

  is.even <- function(x) {(x %% 2) == 0}
  is.odd <- function(x) {(x %% 2) == 1}


  ## [CS.Ind.fun] - "Competitive Sampling Individual function"
  ## Given parameters of gambles H and L and total Sample size, returns a df indicating the probability that mean(H) > mean(L)

  CS.Ind.fun <- function(H.pars, L.pars, Samples.Max = 10) {

    H.Mu <- H.pars[1] * H.pars[2] + H.pars[3] * (1 - H.pars[2])  # Mean of H
    L.Mu <- L.pars[1] * L.pars[2] + L.pars[3] * (1 - L.pars[2])  # Mean of L

    if(H.Mu <= L.Mu) return(paste("Mean of H is less than or equal toMean of L! Rechoose gambles"))

    if(H.Mu > L.Mu) {

      Output.df <- as.data.frame(matrix(NA, nrow = Samples.Max, ncol = 3))

      for (Samples.i in 1:Samples.Max) {

        ## Even Samples > 1

        if (is.even(Samples.i) & Samples.i > 1) {

          H.Samples <- Samples.i / 2
          L.Samples <- Samples.i / 2

          H.Means <- ((0:H.Samples) * H.pars[1] + (H.Samples:0) * H.pars[3]) / H.Samples  # All possible mean outcomes from option A with sample size H.Samples
          H.Probabilities <- dbinom(0:H.Samples, H.Samples, H.pars[2])  # Probability of obtaining each possible mean outcome from option A with sample size H.Samples

          L.Means <- ((0:L.Samples)*L.pars[1] + (L.Samples:0) * L.pars[3]) / L.Samples
          L.Probabilities <- dbinom(0:L.Samples, L.Samples, L.pars[2])

          ## For each possible A Mean outcome, calculate the probability that A B mean outcome beats it

          p.Hwins.vec<-c()

          for (i in 1:length(H.Means)) {p.Hwins.vec[i]<-sum(L.Probabilities[L.Means<H.Means[i]])*H.Probabilities[i]}

          p.Want.H <- sum(p.Hwins.vec)

        }

        ## Odd Samples > 1

        if (is.odd(Samples.i) & Samples.i > 1) {

          ## Start where A gets the extra sample

          H.Samples <- floor(Samples.i / 2)
          L.Samples <- ceiling(Samples.i / 2)

          H.Means<-((0:H.Samples)*H.pars[1] + (H.Samples:0)*H.pars[3])/H.Samples  # All possible mean outcomes from option A with sample size H.Samples
          H.Probabilities<-dbinom(0:H.Samples,H.Samples,H.pars[2])  # Probability of obtaining each possible mean outcome from option A with sample size H.Samples

          L.Means<-((0:L.Samples)*L.pars[1] + (L.Samples:0)*L.pars[3])/L.Samples
          L.Probabilities<-dbinom(0:L.Samples,L.Samples,L.pars[2])

          p.Hwins.vec<-c()

          for (i in 1:length(H.Means)) {p.Hwins.vec[i]<-sum(L.Probabilities[L.Means<H.Means[i]])*H.Probabilities[i]}

          p.Hwins.left<-sum(p.Hwins.vec)      ## p.Hwins.left is the probability that A wins given that option A gets the extra sample

          ## Now repeat where B gets the extra sample

          H.Samples <- ceiling(Samples.i / 2)
          L.Samples <- floor(Samples.i / 2)

          H.Means<-((0:H.Samples)*H.pars[1] + (H.Samples:0)*H.pars[3])/H.Samples  # All possible mean outcomes from option A with sample size H.Samples
          H.Probabilities<-dbinom(0:H.Samples,H.Samples,H.pars[2])  # Probability of obtaining each possible mean outcome from option A with sample size H.Samples

          L.Means<-((0:L.Samples)*L.pars[1] + (L.Samples:0)*L.pars[3])/L.Samples
          L.Probabilities<-dbinom(0:L.Samples,L.Samples,L.pars[2])

          p.Hwins.vec<-c()

          for (i in 1:length(H.Means)) {p.Hwins.vec[i]<-sum(L.Probabilities[L.Means<H.Means[i]])*H.Probabilities[i]}

          p.Hwins.right<-sum(p.Hwins.vec)  ## p.Hwins.right is the probability that A wins given that option B gets the extra sample

          p.Want.H<-mean(c(p.Hwins.left,p.Hwins.right))  ## p.Hwins is the average of the two prior probabilities

        }

        ## Samples == 1

        if(Samples.i == 1) {

          ## First calculate outcomes where A gets the sample

          H.Samples <- 1
          L.Samples <- 0

          H.Means<-((0:H.Samples)*H.pars[1] + (H.Samples:0)*H.pars[3])/H.Samples  # All possible mean outcomes from option A with sample size H.Samples
          H.Probabilities<-dbinom(0:H.Samples,H.Samples,H.pars[2])  # Probability of obtaining each possible mean outcome from option A with sample size H.Samples

          p.ChooseH.left<-sum(H.Probabilities[H.Means>0])

          ## Now calculate outcomes where B gets the sample

          H.Samples <- 0
          L.Samples <- 1

          L.Means<-((0:L.Samples)*L.pars[1] + (L.Samples:0)*L.pars[3])/L.Samples
          L.Probabilities<-dbinom(0:L.Samples,L.Samples,L.pars[2])

          p.ChooseH.right<-sum(L.Probabilities[L.Means<0])

          ## Average the two together

          p.Want.H<-mean(c(p.ChooseH.left,p.ChooseH.right))


        }

        p.Want.L <- 1 - p.Want.H

        Output.df[Samples.i, ] <- c(p.Want.H, p.Want.L, Samples.i)
      }

      names(Output.df) <- c("p.Want.H", "p.Want.L", "Samples")

      return(Output.df)
    }



  }


  ### Create Gamble.Sim.df Table


  # 1. Two pH.yoff distributions: A: (H.x, H.p, H.y)   B: (L.x,L.p,L.y)
  # 2. Sim.n pairs of gambles
  # 3. For each gamble, p is sampled from Unif(0,1). x's are sampled from U(0,100), y's are sampled from U(-100,0)


  #### [Gamble.Sim.df]
  ## Randomly sample two gambles A and B, where A and B each have a gain x with probability p, and a loss y with probability 1-p.
  # H is the HEV option, B is the LEV option


  Gamble.Sim.df <- as.data.frame(matrix(NA, nrow = Sim.n, ncol = 7))


  ### Create Sim.n Gamble pairs (call gambles A and B now, they will be transformed into H and L soon...)

  Gamble.Sim.df[,1] <- 1:Sim.n
  Gamble.Sim.df[,2] <- runif(Sim.n, min(A.x.Interval), max(A.x.Interval))
  Gamble.Sim.df[,3] <- runif(Sim.n, min(A.p.Interval), max(A.p.Interval))
  Gamble.Sim.df[,4] <- runif(Sim.n, min(A.y.Interval), max(A.y.Interval))
  Gamble.Sim.df[,5] <- runif(Sim.n, min(B.x.Interval), max(B.x.Interval))
  Gamble.Sim.df[,6] <- runif(Sim.n, min(B.p.Interval), max(B.p.Interval))
  Gamble.Sim.df[,7] <- runif(Sim.n, min(B.y.Interval), max(B.y.Interval))



  names(Gamble.Sim.df)<-c("Gamble.Num", "A.x", "A.p", "A.y", "B.x", "B.p", "B.y")

  Gamble.Sim.df$A.Mu <- with(Gamble.Sim.df, A.x * A.p + A.y * (1 - A.p)) # Calculate gamble A means
  Gamble.Sim.df$B.Mu <- with(Gamble.Sim.df, B.x * B.p + B.y * (1 - B.p)) # Calculate gamble B means

  ## Create gambles H and L depending on means calculated above

  A.Higher.Index <- Gamble.Sim.df$A.Mu > Gamble.Sim.df$B.Mu     ## Indexes gambles where A.mu > B.mu

  Gamble.Sim.df$H.x[A.Higher.Index] <- Gamble.Sim.df$A.x[A.Higher.Index]
  Gamble.Sim.df$H.y[A.Higher.Index] <- Gamble.Sim.df$A.y[A.Higher.Index]
  Gamble.Sim.df$H.p[A.Higher.Index] <- Gamble.Sim.df$A.p[A.Higher.Index]
  Gamble.Sim.df$L.x[A.Higher.Index] <- Gamble.Sim.df$B.x[A.Higher.Index]
  Gamble.Sim.df$L.p[A.Higher.Index] <- Gamble.Sim.df$B.p[A.Higher.Index]
  Gamble.Sim.df$L.y[A.Higher.Index] <- Gamble.Sim.df$B.y[A.Higher.Index]

  Gamble.Sim.df$H.x[!A.Higher.Index] <- Gamble.Sim.df$B.x[!A.Higher.Index]
  Gamble.Sim.df$H.p[!A.Higher.Index] <- Gamble.Sim.df$B.p[!A.Higher.Index]
  Gamble.Sim.df$H.y[!A.Higher.Index] <- Gamble.Sim.df$B.y[!A.Higher.Index]
  Gamble.Sim.df$L.x[!A.Higher.Index] <- Gamble.Sim.df$A.x[!A.Higher.Index]
  Gamble.Sim.df$L.p[!A.Higher.Index] <- Gamble.Sim.df$A.p[!A.Higher.Index]
  Gamble.Sim.df$L.y[!A.Higher.Index] <- Gamble.Sim.df$A.y[!A.Higher.Index]



  #### Create expected outcomes based on Gamble.Sim.df

  Expected.Outcomes.ls <- list()

  for (Gamble.i in 1:nrow(Gamble.Sim.df)) {
    if (Print.N) {print(paste("Gamble ", Gamble.i, " out of ", nrow(Gamble.Sim.df), ". ", round(Gamble.i / nrow(Gamble.Sim.df), 2) * 100, "% Complete.", sep = ""))}

    Expected.Outcomes.ls[[Gamble.i]] <- with(Gamble.Sim.df[Gamble.i,], CS.Ind.fun(c(H.x, H.p, H.y), c(L.x, L.p, L.y), Max.N))

  }

  ########## Aggregate across all gambles

  Final.pHEV <- c()

  for (Samples.i in 1:Max.N) {

    Final.pHEV <- c(Final.pHEV, mean(as.numeric(lapply(Expected.Outcomes.ls, FUN = function(x) {x[Samples.i,1]}))))
  }

  Comp.Samples.df <- expand.grid("Agent" = 1:Max.N, "Competitor" = 1:Max.N)

  for (i in 1:nrow(Comp.Samples.df)) {


    if(Comp.Samples.df$Agent[i] == Comp.Samples.df$Competitor[i]) {Comp.Samples.df$pHEV[i] <- .5}
    if(Comp.Samples.df$Agent[i] < Comp.Samples.df$Competitor[i]) {Comp.Samples.df$pHEV[i] <- Final.pHEV[Comp.Samples.df$Agent[i]]}
    if(Comp.Samples.df$Agent[i] > Comp.Samples.df$Competitor[i]) {Comp.Samples.df$pHEV[i] <- 1 - Final.pHEV[Comp.Samples.df$Competitor[i]]}

  }

  Output <- list("Solitary Performance" = Final.pHEV, "Competition Performance" = Comp.Samples.df)

  return(Output)

}
