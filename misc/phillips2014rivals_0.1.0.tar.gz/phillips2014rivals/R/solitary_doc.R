#' Solitary group data
#'
#' Solitary condition data at the game level
#'
#'
#' @format A data frame containing 720 rows and 58 columns.
#' \describe{
#'   \item{Index.Game}{string. The participant and game number.}
#'   \item{Sampling.Trials}{integer. The number of samples the participant took before making a decision.}
#'   \item{ChoiceHEV}{logical. Was the selected option the option with the higher EV?}
#'   \item{Choice}{integer. Which option did the player choose?}
#'   \item{Round}{integer. The round number. Ranges from 1 to 5.}
#'   \item{Urn.0}{numeric. Characteristics of urn 0.}
#'   \item{Urn.1}{numeric. Characteristics of urn 1.}
#'  }
#' @examples
#'
#'
#'
#'  # Histogram of trials
#'
#'  hist(Sol.Game.df$Sampling.Trials)
#'
#'


"Sol.Game.df"
